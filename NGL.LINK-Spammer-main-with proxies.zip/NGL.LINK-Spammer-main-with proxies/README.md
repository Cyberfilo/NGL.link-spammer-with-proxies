# NGL.LINK Spammer!
This Spammer Was Meant To Joke Around With Your Friends.
I am not Responsible For Any Misuse Of This Program For Example (Harassing & Bullying).
Follow My Instagram, @ykw
